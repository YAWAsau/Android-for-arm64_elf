/*
   ctdb system specific code to manage raw sockets on linux

   Copyright (C) Ronnie Sahlberg  2007
   Copyright (C) Andrew Tridgell  2007
   Copyright (C) Marc Dequènes (Duck) 2009
   Copyright (C) Volker Lendecke 2012

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, see <http://www.gnu.org/licenses/>.
*/

#include "replace.h"

/*
 * Use BSD struct tcphdr field names for portability.  Modern glibc
 * makes them available by default via <netinet/tcp.h> but older glibc
 * requires __FAVOR_BSD to be defined.
 *
 * __FAVOR_BSD is normally defined in <features.h> if _DEFAULT_SOURCE
 * (new) or _BSD_SOURCE (now deprecated) is set and _GNU_SOURCE is not
 * set.  Including "replace.h" above causes <features.h> to be
 * indirectly included and this will not set __FAVOR_BSD because
 * _GNU_SOURCE is set in Samba's "config.h" (which is included by
 * "replace.h").
 *
 * Therefore, set __FAVOR_BSD by hand below.
 */
#define __FAVOR_BSD 1
#include "system/network.h"

#ifdef HAVE_NETINET_IF_ETHER_H
#include <netinet/if_ether.h>
#endif
#ifdef HAVE_NETINET_IP6_H
#include <netinet/ip6.h>
#endif
#ifdef HAVE_NETINET_ICMP6_H
#include <netinet/icmp6.h>
#endif
#ifdef HAVE_LINUX_IF_PACKET_H
#include <linux/if_packet.h>
#endif

#ifndef ETHERTYPE_IP6
#define ETHERTYPE_IP6 0x86dd
#endif

#include <talloc.h>

#include "lib/util/debug.h"
#include "lib/util/blocking.h"

#include "protocol/protocol.h"
#include "protocol/protocol_util.h"

#include "common/logging.h"
#include "common/system_socket.h"

/*
  uint16 checksum for n bytes
 */
static uint32_t uint16_checksum(uint8_t *data, size_t n)
{
	uint32_t sum=0;
	uint16_t value;

	while (n>=2) {
		memcpy(&value, data, 2);
		sum += (uint32_t)ntohs(value);
		data += 2;
		n -= 2;
	}
	if (n == 1) {
		sum += (uint32_t)ntohs(*data);
	}
	return sum;
}

struct ctdb_sys_local_ips_context {
	struct ifaddrs *ifa;
};

static int ctdb_sys_local_ips_destructor(
	struct ctdb_sys_local_ips_context *ips_ctx)
{
	freeifaddrs(ips_ctx->ifa);
	ips_ctx->ifa = NULL;

	return 0;
}

int ctdb_sys_local_ips_init(TALLOC_CTX *ctx,
			    struct ctdb_sys_local_ips_context **ips_ctx)
{
	struct ctdb_sys_local_ips_context *t = NULL;
	int ret = 0;

	t = talloc(ctx, struct ctdb_sys_local_ips_context);
	if (t == NULL) {
		return ENOMEM;
	}

	ret = getifaddrs(&t->ifa);
	if (ret != 0) {
		ret = errno;
		talloc_free(t);
		return ret;
	}

	talloc_set_destructor(t, ctdb_sys_local_ips_destructor);
	*ips_ctx = t;

	return ret;
}

bool ctdb_sys_local_ip_check(const struct ctdb_sys_local_ips_context *ips_ctx,
			     const ctdb_sock_addr *addr)
{
	struct ifaddrs *ifa = NULL;
	int ret;

	for (ifa = ips_ctx->ifa; ifa != NULL; ifa = ifa->ifa_next) {
		ctdb_sock_addr sock_addr;
		bool match;

		if (ifa->ifa_addr == NULL)
			continue;

		/* Ignore non-IPv4/IPv6 interfaces */
		switch (ifa->ifa_addr->sa_family) {
		case AF_INET:
		case AF_INET6:
			break;
		default:
			continue;
		}

		ret = ctdb_sock_addr_from_sockaddr(ifa->ifa_addr, &sock_addr);
		if (ret != 0) {
			return false;
		}

		match = ctdb_sock_addr_same_ip(&sock_addr, addr);
		if (match) {
			return true;
		}
	}

	return false;
}

bool ctdb_sys_bind_ip_check(const ctdb_sock_addr *_addr)
{
	int s;
	int ret;
	ctdb_sock_addr __addr = *_addr;
	ctdb_sock_addr *addr = &__addr;
	socklen_t addrlen = 0;

	switch (addr->sa.sa_family) {
	case AF_INET:
		addr->ip.sin_port = 0;
		addrlen = sizeof(struct sockaddr_in);
		break;
	case AF_INET6:
		addr->ip6.sin6_port = 0;
		addrlen = sizeof(struct sockaddr_in6);
		break;
	}

	s = socket(addr->sa.sa_family, SOCK_STREAM, IPPROTO_TCP);
	if (s == -1) {
		return false;
	}

	ret = bind(s, (struct sockaddr *)addr, addrlen);

	close(s);
	return ret == 0;
}

/*
 * See if the given IP is currently on an interface
 */
bool ctdb_sys_have_ip(const ctdb_sock_addr *addr)
{
	struct ctdb_sys_local_ips_context *ips_ctx = NULL;
	bool have_ip;
	int ret;

	ret = ctdb_sys_local_ips_init(NULL, &ips_ctx);
	if (ret != 0) {
		DBG_DEBUG("Failed to get local addresses, depending on bind\n");
		have_ip = ctdb_sys_bind_ip_check(addr);
		return have_ip;
	}

	have_ip = ctdb_sys_local_ip_check(ips_ctx, addr);
	talloc_free(ips_ctx);

	return have_ip;
}

/*
 * simple TCP checksum - assumes data is multiple of 2 bytes long
 */
static uint16_t ip_checksum(uint8_t *data, size_t n, struct ip *ip)
{
	uint32_t sum = uint16_checksum(data, n);
	uint16_t sum2;

	sum += uint16_checksum((uint8_t *)&ip->ip_src, sizeof(ip->ip_src));
	sum += uint16_checksum((uint8_t *)&ip->ip_dst, sizeof(ip->ip_dst));
	sum += ip->ip_p + n;
	sum = (sum & 0xFFFF) + (sum >> 16);
	sum = (sum & 0xFFFF) + (sum >> 16);
	sum2 = htons(sum);
	sum2 = ~sum2;
	if (sum2 == 0) {
		return 0xFFFF;
	}
	return sum2;
}

static uint16_t ip6_checksum(uint8_t *data, size_t n, struct ip6_hdr *ip6)
{
	uint16_t phdr[3];
	uint32_t sum = 0;
	uint16_t sum2;
	uint32_t len;

	sum += uint16_checksum((uint8_t *)&ip6->ip6_src, 16);
	sum += uint16_checksum((uint8_t *)&ip6->ip6_dst, 16);

	len = htonl(n);
	phdr[0] = len & UINT16_MAX;
	phdr[1] = (len >> 16) & UINT16_MAX;
	/* ip6_nxt is only 8 bits, so fits comfortably into a uint16_t */
	phdr[2] = htons(ip6->ip6_nxt);
	sum += uint16_checksum((uint8_t *)phdr, sizeof(phdr));

	sum += uint16_checksum(data, n);

	sum = (sum & 0xFFFF) + (sum >> 16);
	sum = (sum & 0xFFFF) + (sum >> 16);
	sum2 = htons(sum);
	sum2 = ~sum2;
	if (sum2 == 0) {
		return 0xFFFF;
	}
	return sum2;
}

/*
 * Send gratuitous ARP request/reply or IPv6 neighbor advertisement
 */

/* For readability */
#undef CTDB_CAN_SEND_ARPS
#ifdef HAVE_PACKETSOCKET
#ifdef HAVE_GETIFADDRS
#ifdef HAVE_IF_NAMETOINDEX
#define CTDB_CAN_SEND_ARPS
#endif
#endif
#endif

#ifdef CTDB_CAN_SEND_ARPS

static inline socklen_t sall_len(struct sockaddr_ll *sll)
{
	/*
	 * To support larger hardware addresses in future, this really
	 * wants to be the 2nd calculation below, which accommodates
	 * 20 octet IPoIB link-level addresses (which do not fit into
	 * a struct sockaddr_ll).  However, for Ethernet that gives an
	 * answer smaller than sizeof(struct sockaddr_ll), which
	 * causes operations on an AF_PACKET socket to fail with
	 * EINVAL.
	 */
	socklen_t len = MAX(sizeof(struct sockaddr_ll),
			    offsetof(struct sockaddr_ll, sll_addr) +
			    sll->sll_halen);
	return len;
}

/*
 * Find an interface using getifaddrs(3)
 *
 * The goal here is to support at least Ethernet and IPoIB (RFC 4391).
 *
 * We need to be able to get link-level (hardware) addresses and IPoIB
 * link-level addresses are 20 octets.
 *
 * ioctl(2) SIOCGIFHWADDR will get link-level addresses but it uses
 * struct sockaddr, which only has space for 14 octets of address.
 * There appears to be no way to use more space.
 *
 * Instead, we use getifaddrs(3).  struct ifaddrs uses pointers
 * (apparently) to struct sockaddr.  Nevertheless, it seems more space
 * is actually allocated (perhaps struct sockaddr_storage?).
 * Similarly, struct sockaddr_ll, used for link-level (i.e. hardware)
 * addresses has only 8 octets of address space.  Therefore, struct
 * sockaddr_storage is used for allocations, with appropriate casts
 * throughout.
 */

static bool check_hwaddr(struct sockaddr *sa, unsigned int index)
{
	struct sockaddr_ll *sall = NULL;

	/*
	 * getifaddrs(3): This field (ifa_addr) may contain a null
	 * pointer
	 */
	if (sa == NULL) {
		return false;
	}

	/* Want struct sockaddr_ll, as per packet(7) */
	if (sa->sa_family != AF_PACKET) {
		return false;
	}

	sall = (struct sockaddr_ll *)sa;

	/*
	 * if_nametoindex(3) returns unsigned int but sll_ifindex is
	 * int!
	 */
	if ((int)index != sall->sll_ifindex) {
		return false;
	}

	if (sall->sll_halen == 0) {
		return false;
	}

	return true;
}

static int find_interface(const char *name,
			  struct sockaddr_storage *hardware_addr,
			  struct sockaddr_storage *broadcast_addr)
{
	unsigned int index = 0;
	struct ifaddrs *ifa = NULL;
	struct ifaddrs *t = NULL;
	bool ok = false;
	int ret = 0;

	/*
	 * Matching will be done by index.
	 *
	 * Interface altname properties (altnames) are a method of
	 * providing alternative names for a network interface (see
	 * ip-link(8)). They can be used to provide some useful
	 * flexibility across cluster nodes where interface name
	 * different and dealing with udev is too bothersome..
	 *
	 * getifaddrs(3) only returns the primary name for each
	 * interface.  If matching is done by name then only a primary
	 * interface name can be matched, so altnames would not be
	 * supported.  The key here is that if_nametoindex() works for
	 * altnames, so matching on the returned index means that
	 * altnames are supported by this function.
	 */
	index = if_nametoindex(name);
	if (index == 0) {
		return ENODEV;
	}

	ret = getifaddrs(&ifa);
	if (ret == -1) {
		ret = errno;
		fprintf(stderr, "Unable to get interface list (%d)\n", ret);
		return ret;
	}

	for (t = ifa; t != NULL; t = t->ifa_next) {
		unsigned int want_flags = IFF_UP | IFF_BROADCAST;
		unsigned int check_flags = want_flags | IFF_NOARP | IFF_LOOPBACK;

		/*
		 * Check the address to ensure this is an AF_PACKET
		 * socket and matches the required index before
		 * allowing soft-failure for loopback/non-arpable
		 */
		ok = check_hwaddr(t->ifa_addr, index);
		if (!ok) {
			continue;
		}

		/* Should be up, with broadcast address, arpable, not loopback */
		if ((t->ifa_flags & check_flags) != want_flags) {
			/*
			 * The interface was found but it isn't one
			 * that we can ARP on...
			 */
			ret = ENXIO;
			goto done;
		}

		ok = check_hwaddr(t->ifa_ifu.ifu_broadaddr, index);
		if (!ok) {
			continue;
		}

		memcpy(hardware_addr,
		       t->ifa_addr,
		       sall_len((struct sockaddr_ll *)t->ifa_addr));
		memcpy(broadcast_addr,
		       t->ifa_broadaddr,
		       sall_len((struct sockaddr_ll *)t->ifa_broadaddr));

		ret = 0;
		goto done;
	}
	ret = ENODEV;

done:
	freeifaddrs(ifa);
	return ret;
}

/*
 * Create IPv4 ARP requests/replies or IPv6 neighbour advertisement
 * packets
 */

/*
 * Some link-level addresses are bigger than a sockaddr_ll.  However,
 * they must fit into a sockaddr_storage, so determine the maximum
 * possible size.
 */
#define SOCKADDR_LL_ADDR_LEN						\
	sizeof(struct sockaddr_storage) - offsetof(struct sockaddr_ll, sll_addr)

#define ARP_BUFFER_SIZE				  \
	sizeof(struct arphdr) +			  \
	SOCKADDR_LL_ADDR_LEN +			  \
	sizeof(struct in_addr) +		  \
	SOCKADDR_LL_ADDR_LEN +			  \
	sizeof(struct in_addr)

/* This will need to be enlarged if more options are added */
#define IP6_NA_BUFFER_SIZE				       \
	sizeof(struct ip6_hdr) +			       \
	sizeof(struct nd_neighbor_advert) +		       \
	sizeof(struct nd_opt_hdr) +			       \
	SOCKADDR_LL_ADDR_LEN

static int arp_build(uint8_t *buffer,
		     size_t buflen,
		     const struct sockaddr_in *addr,
		     const struct sockaddr_ll *hardware_addr,
		     uint16_t arpop,
		     size_t *len)
{
	size_t l = 0;
	uint8_t *p = NULL;
	struct arphdr *ah;

	if (addr->sin_family != AF_INET) {
		return EINVAL;
	}

	switch (arpop) {
	case ARPOP_REQUEST:
	case ARPOP_REPLY:
		break;
	default:
		DBG_ERR("Internal error: invalid op=%" PRIu32 "\n", arpop);
		return EINVAL;
	};

	/*
	 * Could avoid this by checking for overflow after writing
	 * each field, but this feels simpler... and it provides a
	 * summary of the layout, which won't change because it is
	 * standard.
	 */
	l = sizeof(struct arphdr) +
		hardware_addr->sll_halen +
		sizeof(addr->sin_addr) +
		hardware_addr->sll_halen +
		sizeof(addr->sin_addr);
	if (buflen < l) {
		return EMSGSIZE;
	}

	memset(buffer, 0 , l);

	p = buffer;
	ah = (struct arphdr *)p;
	ah->ar_hrd = htons(hardware_addr->sll_hatype);
	ah->ar_pro = htons(ETH_P_IP);
	ah->ar_hln = hardware_addr->sll_halen;
	ah->ar_pln = sizeof(addr->sin_addr);
	ah->ar_op = htons(arpop);
	p += sizeof(struct arphdr);

	memcpy(p, &hardware_addr->sll_addr, hardware_addr->sll_halen);
	p += hardware_addr->sll_halen;
	memcpy(p, &addr->sin_addr, sizeof(addr->sin_addr));
	p += sizeof(addr->sin_addr);
	if (arpop == ARPOP_REQUEST) {
		/* Field must be all 0s - already done by memset() above */
	} else {
		memcpy(p, hardware_addr->sll_addr, hardware_addr->sll_halen);
	}
	p += hardware_addr->sll_halen;
	memcpy(p, &addr->sin_addr, sizeof(addr->sin_addr));

	*len = l;
	return 0;
}

static int ip6_ll_multicast_build(struct sockaddr_ll *in,
				  struct sockaddr_storage *out)
{
	/*
	 * Ethernet multicast: 33:33:00:00:00:01 (see RFC2464, section
	 * 7) - 1st 2 octets are 0x3333, final 4 are the last 4 of the
	 * IPv6 address (see all_nodes_ll_multicast in ip6_na_build())
	 */
	const uint8_t ethernet_multicast[ETH_ALEN] = {
		0x33, 0x33, 0x00, 0x00, 0x00, 0x01
	};
	uint8_t *in_sll_addr = (uint8_t *)in + offsetof(struct sockaddr_ll,
							sll_addr);
	uint8_t *out_sll_addr = (uint8_t *)out + offsetof(struct sockaddr_ll,
							  sll_addr);

	*(struct sockaddr_ll *)out = (struct sockaddr_ll) {
		.sll_family = AF_PACKET,
		.sll_halen = in->sll_halen,
		.sll_protocol = htons(ETH_P_IPV6),
		.sll_ifindex = in->sll_ifindex,
	};

	switch (in->sll_hatype) {
	case ARPHRD_ETHER:
		if (SOCKADDR_LL_ADDR_LEN < sizeof(ethernet_multicast)) {
			return EMSGSIZE;
		}
		memcpy(&out_sll_addr[0],
		       ethernet_multicast,
		       sizeof(ethernet_multicast));
		break;
	case ARPHRD_INFINIBAND:
		/*
		 * RFC4391 and RFC4392 both mention (in passing!) that
		 * the IPoIB link-layer address is 20 octets, so
		 * insist on that.
		 */
		if (in->sll_halen != 20) {
			return EINVAL;
		}

		/*
		 * IPoIB Multicast Mapping is specified in RFC4391,
		 * section 4.
		 *
		 * Comparing examples in
		 * /sys/kernel/debug/ipoib/ib0_mcg, which includes the
		 * following GIDs:
		 *
		 * - ff12:401b:ffff:0:0:0:ffff:ffff
		 * - ff12:601b:ffff:0:0:0:0:1
		 *
		 * with the broadcast address on interface ib0:
		 *
		 * 00:ff:ff:ff:ff:12:40:1b:ff:ff:00:00:00:00:00:00:ff:ff:ff:ff
		 *
		 * The broadcast address is the IPv4 multicast group
		 * GID (note IPoIB signature 0x401b for IPv4),
		 * prefixed with 00:ff:ff:ff (no idea what the prefix
		 * means).
		 *
		 * Given that RFC4391 says:
		 *
		 *   The same mapping function is used for both IPv4
		 *   and IPv6 except for the IPoIB signature field.
		 *
		 * this should mean we should be able to convert the
		 * IPv4 broadcast address to an IPv6 multicast address
		 * by changing the IPoIB signature to 0x601b and the
		 * last 4 octets to 00:00:00:01.  As in the equivalent
		 * Ethernet multicast address, the last 4 octets
		 * appear to be the last 4 octets of the IPv6
		 * multicast address (see all_nodes_ll_multicast).
		 */
		memcpy(&out_sll_addr[0], &in_sll_addr[0], in->sll_halen);
		out_sll_addr[6] = 0x60;
		out_sll_addr[16] = 0x00;
		out_sll_addr[17] = 0x00;
		out_sll_addr[18] = 0x00;
		out_sll_addr[19] = 0x01;
		break;
	default:
		return EPROTONOSUPPORT;
	}

	return 0;
}

static int ip6_na_build(uint8_t *buffer,
			size_t buflen,
			const struct sockaddr_in6 *addr,
			const struct sockaddr_ll *hardware_addr,
			size_t *len)
{
	struct ip6_hdr *ip6;
	/*
	 * IPv6 all nodes link-level multicast address: (see RFC2373,
	 * section 2.7.1)
	 */
	const char *all_nodes_ll_multicast = "ff02::1";
	struct nd_neighbor_advert *nd_na;
	struct nd_opt_hdr *nd_oh;
	uint8_t *p = NULL;
	size_t leftover = 0;
	size_t padding = 0;
	int ret;

	if (addr->sin6_family != AF_INET6) {
		return EINVAL;
	}

	if (buflen < IP6_NA_BUFFER_SIZE) {
		return EMSGSIZE;
	}

	memset(buffer, 0 , buflen);

	ip6 = (struct ip6_hdr *)buffer;
	ip6->ip6_vfc  = 6 << 4;
	/* ip6->ip6_plen set below, before checksum calculation */
	ip6->ip6_nxt  = IPPROTO_ICMPV6;
	ip6->ip6_hlim = 255;
	ip6->ip6_src  = addr->sin6_addr;

	ret = inet_pton(AF_INET6, all_nodes_ll_multicast, &ip6->ip6_dst);
	if (ret != 1) {
		/* Can't happen */
		return EIO;
	}

	nd_na = (struct nd_neighbor_advert *)(buffer +
					      sizeof(struct ip6_hdr));
	nd_na->nd_na_type = ND_NEIGHBOR_ADVERT;
	nd_na->nd_na_code = 0;
	nd_na->nd_na_flags_reserved = ND_NA_FLAG_OVERRIDE;
	nd_na->nd_na_target = addr->sin6_addr;

	/* Option: Target link-layer address */
	nd_oh = (struct nd_opt_hdr *)(buffer +
				      sizeof(struct ip6_hdr) +
				      sizeof(struct nd_neighbor_advert));
	nd_oh->nd_opt_type = ND_OPT_TARGET_LINKADDR;

	/* Hardware address goes here */
	p = buffer +
		sizeof(struct ip6_hdr) +
		sizeof(struct nd_neighbor_advert) +
		sizeof(struct nd_opt_hdr);

	/*
	 * RFC 4861: The length of the option (including the type and
	 * length fields) in units of 8 octets.  For example, the
	 * length for IEEE 802 addresses is 1.
	 *
	 * That is, nd_opt_type and nd_opt_len are 1 octet each, and
	 * an Ethernet address is 6 octets, for a total of 8 octets.
	 * So, nd_opt_len is 1 for Ethernet.
	 *
	 * For IPoIB (according to RFC 4391) this should be 3 so it
	 * can fit 20 octets of IPoIB hardware address (plus
	 * nd_opt_type & nd_opt_len).  So, for IPoIB, 3 * 8 = 24
	 * octets of space is allocated.  However, the IPoIB hardware
	 * address + nd_opt_type + nd_opt_len only fills 22 octets.
	 * So, RFC 4391 says to prepend 2 zeroes to the hardware
	 * address.  Once again, generalise this so it works for at
	 * least Ethernet and IPoIB.
	 *
	 * There is probably a cleverer way of writing the following,
	 * but listen to Kernighan's Law and aim for clarity.
	 */
	nd_oh->nd_opt_len = (2 + hardware_addr->sll_halen) / 8;
	leftover = (2 + hardware_addr->sll_halen) % 8;
	padding = 0;
	if (leftover != 0) {
		nd_oh->nd_opt_len += 1;
		padding = 8 - leftover;
		memset(p, 0, padding);
		p += padding;
	}

	memcpy(p, hardware_addr->sll_addr, hardware_addr->sll_halen);
	p += hardware_addr->sll_halen;

	/*
	 * This is either buried down here (with a helpful comment in
	 * the correct place, above) or the whole nd_opt_len/padding
	 * calculation is done out of order before the original
	 * calculation of ip6->ip6_plen.  This seems to be the lesser
	 * of two evils...
	 */
	ip6->ip6_plen = htons(sizeof(struct nd_neighbor_advert) +
			      sizeof(struct nd_opt_hdr) +
			      hardware_addr->sll_halen +
			      padding);

	nd_na->nd_na_cksum = ip6_checksum((uint8_t *)nd_na,
					  ntohs(ip6->ip6_plen),
					  ip6);

	*len = p - buffer;
	return 0;
}

int ctdb_sys_send_arp(const ctdb_sock_addr *addr, const char *iface)
{
	struct sockaddr_storage hardware_addr = {};
	struct sockaddr_storage broadcast_addr = {};
	struct sockaddr_ll *hardware_addr_ll =
		(struct sockaddr_ll *) &hardware_addr;
	struct sockaddr_ll *broadcast_addr_ll =
		(struct sockaddr_ll *) &broadcast_addr;
	int s = -1;
	struct sockaddr_storage sas = {0};
	socklen_t dest_len = 0;
	uint8_t buffer[MAX(ARP_BUFFER_SIZE, IP6_NA_BUFFER_SIZE)];
	size_t len = 0;
	int ret = 0;

	/* Find interface */
	ret = find_interface(iface, &hardware_addr, &broadcast_addr);
	switch (ret) {
	case 0:
		break;
	case ENODEV:
		DBG_ERR("Interface '%s' not found\n", iface);
		goto done;
	case ENXIO:
		/* Probably loopback, so convert to success */
		ret = 0;
		DBG_DEBUG("Interface '%s' is not ARP-able\n", iface);
		goto done;
	default:
		DBG_ERR("Failed to fetch information for interface '%s' (%d)\n",
			iface,
			ret);
		goto done;
	}

	switch (hardware_addr_ll->sll_hatype) {
	case ARPHRD_ETHER:
	case ARPHRD_INFINIBAND:
		break;
	default:
		DBG_ERR("Not a supported address family (0x%x)\n",
			hardware_addr_ll->sll_hatype);
		ret = EPROTONOSUPPORT;
		goto done;
	}

	s = socket(AF_PACKET, SOCK_DGRAM, 0);
	if (s == -1) {
		ret = errno;
		DBG_ERR("Failed to open socket\n");
		return ret;
	}
	DBG_DEBUG("Created SOCKET FD:%d for sending arp\n", s);

	dest_len = sall_len(hardware_addr_ll);
	ret = bind(s, (struct sockaddr *)hardware_addr_ll, dest_len);
	if (ret == -1) {
		ret = errno;
		DBG_ERR("Failed bind (%d)\n", ret);
		goto done;
	}

	switch (addr->ip.sin_family) {
	case AF_INET:
		/* Send gratuitous ARP */
		hardware_addr_ll->sll_protocol = htons(ETH_P_ARP);
		broadcast_addr_ll->sll_protocol = htons(ETH_P_ARP);
		/*
		 * Unlikely to be different to previous dest_len
		 * calculation, but...
		 */
		dest_len = sall_len(broadcast_addr_ll);

		ret = arp_build(buffer,
				sizeof(buffer),
				&addr->ip,
				hardware_addr_ll,
				ARPOP_REQUEST,
				&len);
		if (ret != 0) {
			DBG_ERR("Failed to build ARP request\n");
			goto done;
		}

		ret = sendto(s,
			     buffer,
			     len,
			     0,
			     (struct sockaddr *)broadcast_addr_ll,
			     dest_len);
		if (ret < 0 ) {
			ret = errno;
			DBG_ERR("Failed sendto\n");
			goto done;
		}

		/* Send unsolicited ARP reply */
		ret = arp_build(buffer,
				sizeof(buffer),
				&addr->ip,
				hardware_addr_ll,
				ARPOP_REPLY,
				&len);
		if (ret != 0) {
			DBG_ERR("Failed to build ARP reply\n");
			goto done;
		}

		ret = sendto(s,
			     buffer,
			     len,
			     0,
			     (struct sockaddr *)broadcast_addr_ll,
			     dest_len);
		if (ret < 0 ) {
			ret = errno;
			DBG_ERR("Failed sendto\n");
			goto done;
		}

		break;

	case AF_INET6:
		/* Send IPv6 NA */
		ret = ip6_ll_multicast_build(broadcast_addr_ll, &sas);
		if (ret != 0) {
			DBG_ERR("Failed to build IPv6 link-level destination\n");
			goto done;
		}

		ret = ip6_na_build(buffer,
				   sizeof(buffer),
				   &addr->ip6,
				   hardware_addr_ll,
				   &len);
		if (ret != 0) {
			DBG_ERR("Failed to build IPv6 neighbor advertisement\n");
			goto done;
		}

		ret = sendto(s,
			     buffer,
			     len,
			     0,
			     (struct sockaddr *)&sas,
			     sall_len((struct sockaddr_ll *)&sas));
		if (ret < 0 ) {
			ret = errno;
			DBG_ERR("Failed sendto\n");
			goto done;
		}

		break;

	default:
		ret = EINVAL;
		DBG_ERR("Not an ipv4/ipv6 address (family is %u)\n",
			addr->ip.sin_family);
		goto done;
	}

	ret = 0;

done:
	if (s != -1) {
		close(s);
	}
	return ret;
}

#else /* CTDB_CAN_SEND_ARPS */

#warning "CTDB will be unable to send ARPs"

int ctdb_sys_send_arp(const ctdb_sock_addr *addr, const char *iface)
{
	/* Not implemented */
	return ENOSYS;
}

#endif /* CTDB_CAN_SEND_ARPS */


#define IP4_TCP_BUFFER_SIZE sizeof(struct ip) + \
			    sizeof(struct tcphdr)

#define IP6_TCP_BUFFER_SIZE sizeof(struct ip6_hdr) + \
			    sizeof(struct tcphdr)

static int tcp4_build(uint8_t *buf,
		      size_t buflen,
		      const struct sockaddr_in *src,
		      const struct sockaddr_in *dst,
		      uint32_t seq,
		      uint32_t ack,
		      int rst,
		      size_t *len)
{
	size_t l = IP4_TCP_BUFFER_SIZE;
	struct {
		struct ip ip;
		struct tcphdr tcp;
	} *ip4pkt;

	if (l != sizeof(*ip4pkt)) {
		return EMSGSIZE;
	}

	if (buflen < l) {
		return EMSGSIZE;
	}

	ip4pkt = (void *)buf;
	memset(ip4pkt, 0, l);

	ip4pkt->ip.ip_v     = 4;
	ip4pkt->ip.ip_hl    = sizeof(ip4pkt->ip)/sizeof(uint32_t);
	ip4pkt->ip.ip_len   = htons(sizeof(ip4pkt));
	ip4pkt->ip.ip_ttl   = 255;
	ip4pkt->ip.ip_p     = IPPROTO_TCP;
	ip4pkt->ip.ip_src.s_addr = src->sin_addr.s_addr;
	ip4pkt->ip.ip_dst.s_addr = dst->sin_addr.s_addr;
	ip4pkt->ip.ip_sum   = 0;

	ip4pkt->tcp.th_sport = src->sin_port;
	ip4pkt->tcp.th_dport = dst->sin_port;
	ip4pkt->tcp.th_seq   = seq;
	ip4pkt->tcp.th_ack   = ack;
	ip4pkt->tcp.th_flags = 0;
	ip4pkt->tcp.th_flags |= TH_ACK;
	if (rst) {
		ip4pkt->tcp.th_flags |= TH_RST;
	}
	ip4pkt->tcp.th_off   = sizeof(ip4pkt->tcp)/sizeof(uint32_t);
	/* this makes it easier to spot in a sniffer */
	ip4pkt->tcp.th_win   = htons(1234);
	ip4pkt->tcp.th_sum   = ip_checksum((uint8_t *)&ip4pkt->tcp,
					   sizeof(ip4pkt->tcp),
					   &ip4pkt->ip);

	*len = l;
	return 0;
}

static int tcp6_build(uint8_t *buf,
		      size_t buflen,
		      const struct sockaddr_in6 *src,
		      const struct sockaddr_in6 *dst,
		      uint32_t seq,
		      uint32_t ack,
		      int rst,
		      size_t *len)
{
	size_t l = IP6_TCP_BUFFER_SIZE;
	struct {
		struct ip6_hdr ip6;
		struct tcphdr tcp;
	} *ip6pkt;

	if (l != sizeof(*ip6pkt)) {
		return EMSGSIZE;
	}

	if (buflen < l) {
		return EMSGSIZE;
	}

	ip6pkt = (void *)buf;
	memset(ip6pkt, 0, l);

	ip6pkt->ip6.ip6_vfc  = 6 << 4;
	ip6pkt->ip6.ip6_plen = htons(sizeof(struct tcphdr));
	ip6pkt->ip6.ip6_nxt  = IPPROTO_TCP;
	ip6pkt->ip6.ip6_hlim = 64;
	ip6pkt->ip6.ip6_src  = src->sin6_addr;
	ip6pkt->ip6.ip6_dst  = dst->sin6_addr;

	ip6pkt->tcp.th_sport = src->sin6_port;
	ip6pkt->tcp.th_dport = dst->sin6_port;
	ip6pkt->tcp.th_seq   = seq;
	ip6pkt->tcp.th_ack   = ack;
	ip6pkt->tcp.th_flags = 0;
	ip6pkt->tcp.th_flags |= TH_ACK;
	if (rst) {
		ip6pkt->tcp.th_flags |= TH_RST;
	}
	ip6pkt->tcp.th_off    = sizeof(ip6pkt->tcp)/sizeof(uint32_t);
	/* this makes it easier to spot in a sniffer */
	ip6pkt->tcp.th_win   = htons(1234);
	ip6pkt->tcp.th_sum   = ip6_checksum((uint8_t *)&ip6pkt->tcp,
					    sizeof(ip6pkt->tcp),
					    &ip6pkt->ip6);

	*len = l;
	return 0;
}

/*
 * Send tcp segment from the specified IP/port to the specified
 * destination IP/port.
 *
 * This is used to trigger the receiving host into sending its own ACK,
 * which should trigger early detection of TCP reset by the client
 * after IP takeover
 *
 * This can also be used to send RST segments (if rst is true) and also
 * if correct seq and ack numbers are provided.
 */
int ctdb_sys_send_tcp(const ctdb_sock_addr *dest,
		      const ctdb_sock_addr *src,
		      uint32_t seq,
		      uint32_t ack,
		      int rst)
{
	uint8_t buf[MAX(IP4_TCP_BUFFER_SIZE, IP6_TCP_BUFFER_SIZE)];
	size_t len = 0;
	int ret;
	int s;
	uint32_t one = 1;
	struct sockaddr_in6 tmpdest = { 0 };
	int saved_errno;

	switch (src->ip.sin_family) {
	case AF_INET:
		ret = tcp4_build(buf,
				 sizeof(buf),
				 &src->ip,
				 &dest->ip,
				 seq,
				 ack,
				 rst,
				 &len);
		if (ret != 0) {
			DBG_ERR("Failed to build TCP packet (%d)\n", ret);
			return ret;
		}

		/* open a raw socket to send this segment from */
		s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
		if (s == -1) {
			DBG_ERR("Failed to open raw socket (%s)\n",
				strerror(errno));
			return -1;
		}

		ret = setsockopt(s, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
		if (ret != 0) {
			DBG_ERR("Failed to setup IP headers (%s)\n",
				strerror(errno));
			close(s);
			return -1;
		}

		ret = sendto(s,
			     buf,
			     len,
			     0,
			     (const struct sockaddr *)&dest->ip,
			     sizeof(dest->ip));
		saved_errno = errno;
		close(s);
		if (ret == -1) {
			D_ERR("Failed sendto (%s)\n", strerror(saved_errno));
			return -1;
		}
		if ((size_t)ret != len) {
			DBG_ERR("Failed sendto - didn't send full packet\n");
			return -1;
		}
		break;

	case AF_INET6:
		ret = tcp6_build(buf,
				 sizeof(buf),
				 &src->ip6,
				 &dest->ip6,
				 seq,
				 ack,
				 rst,
				 &len);
		if (ret != 0) {
			DBG_ERR("Failed to build TCP packet (%d)\n", ret);
			return ret;
		}

		s = socket(AF_INET6, SOCK_RAW, IPPROTO_RAW);
		if (s == -1) {
			DBG_ERR("Failed to open sending socket\n");
			return -1;

		}
		/*
		 * sendto() on an IPv6 raw socket requires the port to
		 * be either 0 or a protocol value
		 */
		tmpdest = dest->ip6;
		tmpdest.sin6_port = 0;

		ret = sendto(s,
			     buf,
			     len,
			     0,
			     (const struct sockaddr *)&tmpdest,
			     sizeof(tmpdest));
		saved_errno = errno;
		close(s);
		if (ret == -1) {
			D_ERR("Failed sendto (%s)\n", strerror(saved_errno));
			return -1;
		}
		if ((size_t)ret != len) {
			DBG_ERR("Failed sendto - didn't send full packet\n");
			return -1;
		}
		break;

	default:
		DBG_ERR("Not an ipv4/v6 address\n");
		return -1;
	}

	return 0;
}

static int tcp4_extract(const uint8_t *ip_pkt,
			size_t pktlen,
			struct sockaddr_in *src,
			struct sockaddr_in *dst,
			uint32_t *ack_seq,
			uint32_t *seq,
			int *rst,
			uint16_t *window)
{
	const struct ip *ip;
	const struct tcphdr *tcp;

	if (pktlen < sizeof(struct ip)) {
		return EMSGSIZE;
	}

	ip = (const struct ip *)ip_pkt;

	/* IPv4 only */
	if (ip->ip_v != 4) {
		return ENOMSG;
	}
	/* Don't look at fragments */
	if ((ntohs(ip->ip_off)&0x1fff) != 0) {
		return ENOMSG;
	}
	/* TCP only */
	if (ip->ip_p != IPPROTO_TCP) {
		return ENOMSG;
	}

	/* Ensure there is enough of the packet to gather required fields */
	if (pktlen <
	    (ip->ip_hl * sizeof(uint32_t)) + offsetof(struct tcphdr, th_sum)) {
		return EMSGSIZE;
	}

	tcp = (const struct tcphdr *)(ip_pkt + (ip->ip_hl * sizeof(uint32_t)));

	src->sin_family      = AF_INET;
	src->sin_addr.s_addr = ip->ip_src.s_addr;
	src->sin_port        = tcp->th_sport;

	dst->sin_family      = AF_INET;
	dst->sin_addr.s_addr = ip->ip_dst.s_addr;
	dst->sin_port        = tcp->th_dport;

	*ack_seq             = tcp->th_ack;
	*seq                 = tcp->th_seq;
	if (window != NULL) {
		*window = tcp->th_win;
	}
	if (rst != NULL) {
		*rst = tcp->th_flags & TH_RST;
	}

	return 0;
}

static int tcp6_extract(const uint8_t *ip_pkt,
			size_t pktlen,
			struct sockaddr_in6 *src,
			struct sockaddr_in6 *dst,
			uint32_t *ack_seq,
			uint32_t *seq,
			int *rst,
			uint16_t *window)
{
	const struct ip6_hdr *ip6;
	const struct tcphdr *tcp;

	/* Ensure there is enough of the packet to gather required fields */
	if (pktlen < sizeof(struct ip6_hdr) + offsetof(struct tcphdr, th_sum)) {
		return EMSGSIZE;
	}

	ip6 = (const struct ip6_hdr *)ip_pkt;

	/* IPv6 only */
	if ((ip6->ip6_vfc >> 4) != 6){
		return ENOMSG;
	}

	/* TCP only */
	if (ip6->ip6_nxt != IPPROTO_TCP) {
		return ENOMSG;
	}

	tcp = (const struct tcphdr *)(ip_pkt + sizeof(struct ip6_hdr));

	src->sin6_family = AF_INET6;
	src->sin6_port   = tcp->th_sport;
	src->sin6_addr   = ip6->ip6_src;

	dst->sin6_family = AF_INET6;
	dst->sin6_port   = tcp->th_dport;
	dst->sin6_addr   = ip6->ip6_dst;

	*ack_seq             = tcp->th_ack;
	*seq                 = tcp->th_seq;
	if (window != NULL) {
		*window = tcp->th_win;
	}
	if (rst != NULL) {
		*rst = tcp->th_flags & TH_RST;
	}

	return 0;
}

/*
 * Packet capture
 *
 * If AF_PACKET is available then use a raw socket otherwise use pcap.
 * wscript has checked to make sure that pcap is available if needed.
 */

#if defined(HAVE_AF_PACKET) && !defined(ENABLE_PCAP)

/*
 * This function is used to open a raw socket to capture from
 */
int ctdb_sys_open_capture_socket(const char *iface, void **private_data)
{
	int s, ret;

	/* Open a socket to capture all traffic */
	s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (s == -1) {
		DBG_ERR("Failed to open raw socket\n");
		return -1;
	}

	DBG_DEBUG("Opened raw socket for TCP tickle capture (fd=%d)\n", s);

	ret = set_blocking(s, false);
	if (ret != 0) {
		DBG_ERR("Failed to set socket non-blocking (%s)\n",
			strerror(errno));
		close(s);
		return -1;
	}

	set_close_on_exec(s);

	return s;
}

/*
 * This function is used to do any additional cleanup required when closing
 * a capture socket.
 * Note that the socket itself is closed automatically in the caller.
 */
int ctdb_sys_close_capture_socket(void *private_data)
{
	return 0;
}


/*
 * called when the raw socket becomes readable
 */
int ctdb_sys_read_tcp_packet(int s, void *private_data,
			     ctdb_sock_addr *src,
			     ctdb_sock_addr *dst,
			     uint32_t *ack_seq,
			     uint32_t *seq,
			     int *rst,
			     uint16_t *window)
{
	ssize_t nread;
	uint8_t pkt[100]; /* Large enough for simple ACK/RST packets */
	struct ether_header *eth;
	int ret;

	nread = recv(s, pkt, sizeof(pkt), MSG_TRUNC);
	if (nread == -1) {
		return errno;
	}
	if ((size_t)nread < sizeof(*eth)) {
		return EMSGSIZE;
	}

	ZERO_STRUCTP(src);
	ZERO_STRUCTP(dst);

	/* Ethernet */
	eth = (struct ether_header *)pkt;

	/* we want either IPv4 or IPv6 */
	if (ntohs(eth->ether_type) == ETHERTYPE_IP) {
		ret = tcp4_extract(pkt + sizeof(struct ether_header),
				   (size_t)nread - sizeof(struct ether_header),
				   &src->ip,
				   &dst->ip,
				   ack_seq,
				   seq,
				   rst,
				   window);
		return ret;

	} else if (ntohs(eth->ether_type) == ETHERTYPE_IP6) {
		ret = tcp6_extract(pkt + sizeof(struct ether_header),
				   (size_t)nread - sizeof(struct ether_header),
				   &src->ip6,
				   &dst->ip6,
				   ack_seq,
				   seq,
				   rst,
				   window);
		return ret;
	}

	return ENOMSG;
}

#else /* defined(HAVE_AF_PACKET) && !defined(ENABLE_PCAP) */

#include <pcap.h>

/*
 * Assume this exists if pcap.h exists - it has been around for a
 * while
 */
#include <pcap/sll.h>

int ctdb_sys_open_capture_socket(const char *iface, void **private_data)
{
	char errbuf[PCAP_ERRBUF_SIZE];
	pcap_t *pt;
	int pcap_packet_type;
	const char *t = NULL;
	int fd;
	int ret;

	pt = pcap_create(iface, errbuf);
	if (pt == NULL) {
		DBG_ERR("Failed to open pcap capture device %s (%s)\n",
			iface,
			errbuf);
		return -1;
	}
	/*
	 * pcap isn't very clear about defaults...
	 */
	ret = pcap_set_snaplen(pt, 100);
	if (ret < 0) {
		DBG_ERR("Failed to set snaplen for pcap capture\n");
		goto fail;
	}
	ret = pcap_set_promisc(pt, 0);
	if (ret < 0) {
		DBG_ERR("Failed to unset promiscuous mode for pcap capture\n");
		goto fail;
	}
	ret = pcap_set_timeout(pt, 0);
	if (ret < 0) {
		DBG_ERR("Failed to set timeout for pcap capture\n");
		goto fail;
	}
#ifdef HAVE_PCAP_SET_IMMEDIATE_MODE
	ret = pcap_set_immediate_mode(pt, 1);
	if (ret < 0) {
		DBG_ERR("Failed to set immediate mode for pcap capture\n");
		goto fail;
	}
#endif
	ret = pcap_activate(pt);
	if (ret < 0) {
		DBG_ERR("Failed to activate pcap capture\n");
		goto fail;
	}

	pcap_packet_type = pcap_datalink(pt);
	switch (pcap_packet_type) {
	case DLT_EN10MB:
		t = "DLT_EN10MB";
		break;
	case DLT_LINUX_SLL:
		t = "DLT_LINUX_SLL";
		break;
#ifdef DLT_LINUX_SLL2
	case DLT_LINUX_SLL2:
		t = "DLT_LINUX_SLL2";
		break;
#endif /* DLT_LINUX_SLL2 */
	default:
		DBG_ERR("Unknown pcap packet type %d\n", pcap_packet_type);
		goto fail;
	}

	fd = pcap_get_selectable_fd(pt);
	DBG_DEBUG("Opened pcap capture for TCP tickle (type=%s, fd=%d)\n",
		  t,
		  fd);

	*((pcap_t **)private_data) = pt;
	return fd;

fail:
	pcap_close(pt);
	return -1;
}

int ctdb_sys_close_capture_socket(void *private_data)
{
	pcap_t *pt = (pcap_t *)private_data;
	pcap_close(pt);
	return 0;
}

int ctdb_sys_read_tcp_packet(int s,
			     void *private_data,
			     ctdb_sock_addr *src,
			     ctdb_sock_addr *dst,
			     uint32_t *ack_seq,
			     uint32_t *seq,
			     int *rst,
			     uint16_t *window)
{
	int ret;
	struct pcap_pkthdr pkthdr;
	const u_char *buffer;
	pcap_t *pt = (pcap_t *)private_data;
	int pcap_packet_type;
	uint16_t ether_type;
	size_t ll_hdr_len;

	buffer=pcap_next(pt, &pkthdr);
	if (buffer==NULL) {
		return ENOMSG;
	}

	ZERO_STRUCTP(src);
	ZERO_STRUCTP(dst);

	pcap_packet_type = pcap_datalink(pt);
	switch (pcap_packet_type) {
	case DLT_EN10MB: {
		const struct ether_header *eth =
			(const struct ether_header *)buffer;
		ether_type = ntohs(eth->ether_type);
		ll_hdr_len = sizeof(struct ether_header);
		break;
	}
	case DLT_LINUX_SLL: {
		const struct sll_header *sll =
			(const struct sll_header *)buffer;
		uint16_t arphrd_type = ntohs(sll->sll_hatype);
		switch (arphrd_type) {
		case ARPHRD_ETHER:
		case ARPHRD_INFINIBAND:
			break;
		default:
			DBG_DEBUG("SLL: Unknown arphrd_type %"PRIu16"\n",
				  arphrd_type);
			return EPROTONOSUPPORT;
		}
		ether_type = ntohs(sll->sll_protocol);
		ll_hdr_len = SLL_HDR_LEN;
		break;
	}
#ifdef DLT_LINUX_SLL2
	case DLT_LINUX_SLL2: {
		const struct sll2_header *sll2 =
			(const struct sll2_header *)buffer;
		uint16_t arphrd_type = ntohs(sll2->sll2_hatype);
		switch (arphrd_type) {
		case ARPHRD_ETHER:
		case ARPHRD_INFINIBAND:
			break;
		default:
			DBG_DEBUG("SLL2: Unknown arphrd_type %"PRIu16"\n",
				  arphrd_type);
			return EPROTONOSUPPORT;
		}
		ether_type = ntohs(sll2->sll2_protocol);
		ll_hdr_len = SLL2_HDR_LEN;
		break;
	}
#endif /* DLT_LINUX_SLL2 */
	default:
		DBG_DEBUG("Unknown pcap packet type %d\n", pcap_packet_type);
		return EPROTONOSUPPORT;
	}

	switch (ether_type) {
	case ETHERTYPE_IP:
		ret = tcp4_extract(buffer + ll_hdr_len,
				   (size_t)pkthdr.caplen - ll_hdr_len,
				   &src->ip,
				   &dst->ip,
				   ack_seq,
				   seq,
				   rst,
				   window);
		break;
	case ETHERTYPE_IP6:
		ret = tcp6_extract(buffer + ll_hdr_len,
				   (size_t)pkthdr.caplen - ll_hdr_len,
				   &src->ip6,
				   &dst->ip6,
				   ack_seq,
				   seq,
				   rst,
				   window);
		break;
	case ETHERTYPE_ARP:
		/* Silently ignore ARP packets */
		return EPROTO;
	default:
		DBG_DEBUG("Unknown ether type %"PRIu16"\n", ether_type);
		return EPROTO;
	}

	return ret;
}

#endif /* defined(HAVE_AF_PACKET) && !defined(ENABLE_PCAP) */
